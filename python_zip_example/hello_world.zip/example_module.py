MODULE_STRING = "This string comes from " + __file__ + "."
